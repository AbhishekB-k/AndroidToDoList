package com.maurya.dtxtodoapp.Fragments

import android.os.Bundle
import android.util.Patterns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.google.firebase.auth.FirebaseAuth
import com.maurya.dtxtodoapp.R
import com.maurya.dtxtodoapp.databinding.FragmentSignInBinding

class SignInFragment : Fragment() {

    private lateinit var fragmentSignInBinding: FragmentSignInBinding
    private lateinit var auth: FirebaseAuth
    private var isLoading: Boolean = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        fragmentSignInBinding = FragmentSignInBinding.inflate(inflater, container, false)
        val view = fragmentSignInBinding.root
        auth = FirebaseAuth.getInstance()
        listeners()
        return view
    }

    private fun listeners() {
        fragmentSignInBinding.dontHaveAccountSignInFragment.setOnClickListener {
            requireActivity().supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, SignUpFragment())
                .addToBackStack(null)
                .commit()
        }

        fragmentSignInBinding.loginButtonSignInFragment.setOnClickListener {
            if (isValidSignInDetails()) {
                signIn()
            }
        }

        fragmentSignInBinding.loginGoogleButtonSignInFragment.setOnClickListener {
            Toast.makeText(context, "Feature coming soon", Toast.LENGTH_SHORT).show()
        }

        fragmentSignInBinding.forgetPasswordSignInFragment.setOnClickListener {
            Toast.makeText(context, "Feature coming soon", Toast.LENGTH_SHORT).show()
        }
    }

    private fun signIn() {
        loading(true)
        val email = fragmentSignInBinding.emailSignInFragment.text.toString().trim()
        val password = fragmentSignInBinding.passwordSignInFragment.text.toString().trim()

        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Toast.makeText(context, "Signed In", Toast.LENGTH_SHORT).show()
                    requireActivity().supportFragmentManager.beginTransaction()
                        .replace(R.id.fragment_container, HomeFragment())
                        .addToBackStack(null)
                        .commit()
                }
            }
            .addOnFailureListener {
                Toast.makeText(context, it.localizedMessage, Toast.LENGTH_SHORT).show()
                loading(false)
            }
    }

    private fun isValidSignInDetails(): Boolean {
        return when {
            fragmentSignInBinding.emailSignInFragment.text.toString().trim().isEmpty() -> {
                showToast("Enter Your email ")
                false
            }
            !Patterns.EMAIL_ADDRESS.matcher(fragmentSignInBinding.emailSignInFragment.text.toString()).matches() -> {
                showToast("Enter Valid Email ")
                false
            }
            fragmentSignInBinding.passwordSignInFragment.text.toString().trim().isEmpty() -> {
                showToast("Enter Password ")
                false
            }
            else -> true
        }
    }

    private fun loading(isLoading: Boolean) {
        if (isLoading) {
            fragmentSignInBinding.loginButtonSignInFragment.visibility = View.INVISIBLE
            fragmentSignInBinding.progressBaSignInFragment.visibility = View.VISIBLE
        } else {
            fragmentSignInBinding.progressBaSignInFragment.visibility = View.INVISIBLE
            fragmentSignInBinding.loginButtonSignInFragment.visibility = View.VISIBLE
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }
}
